from myCoin.coin import Coin
from myCoin.coin import edwin_coin